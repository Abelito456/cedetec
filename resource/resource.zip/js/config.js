/*const URL = "http://cedetec.org/portal_empleo/";
const PATHNAME = "/portal_empleo/";
const PERFILES = "http://cedetec.org/portal_empleo/resource/images/perfiles/";*/

//Config local
const URL = "http://localhost/portal_empleo/";
const PATHNAME = "/portal_empleo/";
const PERFILES = "http://localhost/portal_empleo/resource/images/perfiles/";