/*Codigo de usuarios */
var data_User=null;
var usuarios = new Usuarios();
var loginUser = () => {
    usuarios.loginUser();
}

var sessionClose = () => {
    usuarios.sessionClose();
}

var restablecerUser = () => {
    usuarios.restablecerUser();
}

/** Restablecer desde la url "user/registro" */
var restablecerUsers = () => {
    usuarios.restablecerUsers();
}

var restablecerEmpresa = () => {
    usuarios.restablecerEmpresa();
}

var restablecerEmpresaUser = () => {
    usuarios.restablecerEmpresaUser();
}

var archivo = (evt) => {
    usuarios.archivo(evt, "fotos");
}

var getIdentificaciones=()=>{
    usuarios.getIdentificaciones(null,1);
}

var getCategorias=()=>{
    usuarios.getCategorias(null,1);
}
     
/*Reset contraseña*/
$(function () {
    $("#btn-reset").click(function () {
        let id = document.getElementById("id").value;
        if (id != ""){
            usuarios.resetPassword(id);
            return false;
        }
        
    });
});

/*Reset contraseña save*/
$(function () {
    $("#btn-resetsave").click(function () {
        let password = document.getElementById("password").value;
        let repassword = document.getElementById("repassword").value;
        if (password != "" && repassword != ""){
            usuarios.resetPasswordSave(password,repassword);
            return false;
        }
        
    });
});

/*Codigo de registro usuario-rol persona (PANEL ADMIN)*/
$(function () {
    $("#btn-registro").click(function () {
        return usuarios.registroUser();
    });

    $("#registerClose").click(function(){
        usuarios.restablecerUser();
    });

    $("#deleteUser").click(function(){
        usuarios.deleteUser(data_User);
        data_User=null;
    });

});

/*Codigo de registro usuario-rol empresa (PANEL ADMIN)*/
$(function () {
    $("#btn-registro-empresa").click(function () {
      return usuarios.registroEmpresa();
    });
    
    $("#registerCloseEmp").click(function(){
        usuarios.restablecerEmpresa();
    });
});

/*Codigo de registro usuario-rol empresa*/
$(function () {
    $("#btn-registro-empresaU").click(function () {
        let id = document.getElementById("id").value;
        let nomb_emp = document.getElementById("nomb_emp").value;
        let razon_s = document.getElementById("razon_s").value;
        let direccion = document.getElementById("direccion").value;
        let telefono_emp = document.getElementById("telefono_emp").value;
        let password = document.getElementById("password").value;
        if (id != "" && nomb_emp != "" && razon_s != "" && direccion != "" && telefono_emp != "" && password != "") {
            usuarios.registroEmpresaUser(id, nomb_emp, razon_s, direccion, telefono_emp, password);
            return false;
        }
    });
});


/*Codigo de registro usuario-rol persona*/
$(function () {
    $("#btn-registro-users").click(function () {
        let nomb_pers = document.getElementById("nomb_pers").value;
        let ape_pers = document.getElementById("ape_pers").value;
        let codi_iden = document.getElementById("codi_iden");
        let identificacion = codi_iden.options[codi_iden.selectedIndex].value;
        let id = document.getElementById("id").value;
        let direccion = document.getElementById("direccion").value;
        let password = document.getElementById("password").value;
        if (nomb_pers != "" && ape_pers != "" && identificacion != "Seleccione un tipo de identificación" && id != "" && direccion != "" && password != "") {
            usuarios.registroUsers(nomb_pers, ape_pers, identificacion, id, direccion, password);
            return false;
        }

    });
});

var getUsers = (page) => {
    let valor = document.getElementById("filtrarUser").value;
    usuarios.getUsers(valor,page);
}

var getEmpresas = (page) => {
    let valor_emp = document.getElementById("filtrarEmpresa").value;
    usuarios.getEmpresas(valor_emp,page);
}

var dataUser = (data) => {
    usuarios.editUser(data);
    //console.log(data);
}

var deleteUser = (data) =>{
    document.getElementById("iduser").innerHTML="Identificación: "+data.id;
    document.getElementById("nombreuser").innerHTML="Nombre: "+data.nomb_pers+" "+ data.ape_pers;
    data_User=data;
}

var dataEmpresa = (data) => {
    usuarios.editEmpresa(data);
}

/*Actualizar perfil save*/
$(function () {
    $("#btn-act-perfil").click(function () {
        return usuarios.actUser();
    });
});

/*EMPRESA*/
var empresa=new Empresa();

var restablecerConvocatoria = () => {
    empresa.restablecerConvocatoria();
}

var getCategorias_laborales=()=>{
    empresa.getCategorias_laborales(null,1);
}

var getContratos=()=>{
    empresa.getContratos(null,1);
}


$(function(){
    $("#registerConvocatoria").click(function(){
        return empresa.registerConvocatorias();
    });
    
    $("#convocatoriaClose").click(function(){
        empresa.restablecerConvocatoria();
    });
});

var getConvocatorias = (page) => {
    let valor = document.getElementById("filtrarConvocatoria").value;
    empresa.getConvocatorias(valor,page);
}

var dataConvocatoria = (data) => {
    empresa.editConvocatoria(data);
}

$(function(){
    $("#id_categoria").change(function(){
      var categoria = $(this).val();
      empresa.buscarPerfil(categoria);
    });
});

/**PERSONA */

var persona=new Persona();

var getIdentificaciones=()=>{
    persona.getIdentificaciones(null,1);
}

var getEstadoCivil=()=>{
    persona.getEstadoCivil(null,1);
}

var getTipoEstudio=()=>{
    persona.getTipoEstudio(null,1);
}

var getListaEstudios = (page) => {
    let valor = document.getElementById("filtrarEstudio").value;
    persona.getListaEstudios(valor,page);
}

$(function(){
    $("#registerDatosPersonales").click(function(){
        return persona.registerDatosPersonales();
    });
    
    $("#personaClose").click(function(){
        persona.restablecerDatosp();
    });
});

var dataPersona = (data) => {
    persona.getDataPersona(data);
    //console.log(data);
}

/*INDEX*/ 
var dataConvo = (data) => {
    usuarios.verOferta(data);
    //console.log(data);
}

$(function () {
    $("#verOfertaClose").click(function(){
        usuarios.restablecerverOferta();
    });

});

var getListaConvocatoria = (page) => {
    let valor = document.getElementById("filtrarConvo").value;
    usuarios.getListaConvocatoria(valor,page);
}

/*Codigo de postular a una convocatoria*/
$(function () {
    
    $("#btn-postular").click(function () {
        return usuarios.postularConvo();
    });
});

$().ready(function () {
    //variable local
    let URLactual = window.location.pathname;
    usuarios.userData(URLactual);

    $("#validate").validate();


    switch (URLactual) {
        case PATHNAME:
            $(".carouselImg").owlCarousel({
                loop: true,
                margin: 10,
                autoplay: true,
                autoplayTimeout: 6000,
                autoplayHoverPause: true,
                lazyLoad : true,
                responsiveClass:true,
                responsive: {
                    0: {
                        items: 1
                    },
                    600: {
                        items: 3
                    },
                    1000: {
                        items: 4
                    }
                }
            });

            $.post(
                URL + "index/getConvocatorias", {},
                (response) => {
                    $("#resultsConvo").html(response);

                    $(".carouselConvocatorias").owlCarousel({
                        loop: true,
                        margin: 20,
                        autoplay: true,
                        autoplayTimeout: 6000,
                        autoplayHoverPause: true,
                        lazyLoad : true,
                        responsiveClass:true,
                        responsive: {
                            0: {
                                items: 1
                            },
                            600: {
                                items: 2
                            },
                            1000: {
                                items: 2
                            }
                        }
                    });
                    
                }
            );

            break;
        case PATHNAME + "admin/user":
            document.getElementById('foto_pers').addEventListener('change', archivo, false);
            document.getElementById("fotos").innerHTML = ['<img class="img60" src="', PATHNAME + "/resource/images/perfiles/personas/user.png", '" title="', , '" />'].join('');
            getIdentificaciones();
            getCategorias();
            getUsers(1);
            break;

        case PATHNAME + "admin/empresa":
            document.getElementById('logo').addEventListener('change', archivo, false);
            document.getElementById("fotos").innerHTML = ['<img class="img60" src="', PATHNAME + "/resource/images/perfiles/empresas/user.png", '" title="', , '" />'].join('');
            getEmpresas(1);
            break;

        case PATHNAME + "user/registroempresa":
            document.getElementById("fotos").innerHTML = ['<img class="img60" src="', PATHNAME + "/resource/images/perfiles/empresas/user.png", '" title="', , '" />'].join('');
            document.getElementById('logo').addEventListener('change', archivo, false);
            break;

        case PATHNAME + "user/registro":
            document.getElementById("fotos").innerHTML = ['<img class="img60" src="', PATHNAME + "/resource/images/perfiles/personas/user.png", '" title="', , '" />'].join('');
            let count = 1;
            $.post(
                URL + "user/getIdentificaciones", {},
                (response) => {
                    try {
                        let item = JSON.parse(response);

                        document.getElementById('codi_iden').options[0] = new Option("Seleccione un tipo de identificación", 0);
                        if (item.results.length > 0) {
                            for (let i = 0; i <= item.results.length; i++) {
                                document.getElementById('codi_iden').options[count] = new Option(item.results[i].desc_iden, item.results[i].codi_iden);
                                count++;

                            }
                        }

                    } catch (error) {

                    }


                }
            );

            document.getElementById('foto_pers').addEventListener('change', archivo, false);
            break;

   

        case PATHNAME + "persona/datospersonales":
            document.getElementById("fotos").innerHTML = ['<img class="img60" src="', PATHNAME + "/resource/images/perfiles/personas/user.png", '" title="', , '" />'].join('');
            getIdentificaciones();
            getEstadoCivil();
            document.getElementById('foto_pers').addEventListener('change', archivo, false);
            break;

            case PATHNAME + "persona/datosacademicos":
                getTipoEstudio();
                getListaEstudios(1);
            break;
            
            case PATHNAME + "empresa/convocatorias":
                    $(window).on('load', function () {
                        setTimeout(function () {
                      $(".loader-page").css({visibility:"hidden",opacity:"0"})
                    }, 2000);
                       
                  });
                  
                getCategorias_laborales();
                getContratos();
                getConvocatorias(1);
            break;

            case PATHNAME + "user/perfil":
                document.getElementById('foto_pers').addEventListener('change', archivo, false);
                usuarios.actdataUser();
            break;
            
            case PATHNAME + "user/convocatorias":
                getListaConvocatoria(1)
            break;
            
            
    }
});