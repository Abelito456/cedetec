class Persona extends Uploadpicture{
    //metodo constructor
    constructor() {
        //hace referencia al metodo constructor de la clase que se esta heredando Uploadpicture
        //invocar todas las propiedades, metodos u objetos de la clase heredada
        super();
        //objetos para actualizar datos
        this.funcion=0;
        //id del usuario que se va actualizar
        this.id_persona=0;
        //foto del usuario que se va actualizar
        this.perfil=null;
    }

    getIdentificaciones(iden, funcion) {
        let count = 1;
        $.post(
            URL + "persona/getIdentificaciones", {},
            (response) => {
                //console.log(response);
                try {
                    let item = JSON.parse(response);
                    //console.log(item);
                    document.getElementById('codi_iden').options[0] = new Option("Seleccione un tipo de identificación", 0);
                    if (item.length > 0) {
                        
                        for (let i = 0; i <= item.length; i++) {
                            switch (funcion) {
                                case 1:
                                    document.getElementById('codi_iden').options[count] = new Option(item[i].desc_iden, item[i].codi_iden);
                                    count++;
                                    break;
                            
                                case 2:
                                        document.getElementById('codi_iden').options[count] = new Option(item[i].desc_iden, item[i].codi_iden);
                                    if (item[i].codi_iden == iden) {
                                        i++;
                                        document.getElementById('codi_iden').selectedIndex=i;
                                        i--;
                                    }
                                    count++;
                                    break;
                            }
                        }
                    }

                } catch (error) {

                }


            }
        );
    }

    getEstadoCivil(estado, funcion) {
        let count = 1;
        $.post(
            URL + "persona/getEstadoCivil", {},
            (response) => {
                //console.log(response);
                try {
                    let item = JSON.parse(response);
                    //console.log(item);
                    document.getElementById('esta_pers').options[0] = new Option("Seleccione un estado civil", 0);
                    if (item.length > 0) {
                        
                        for (let i = 0; i <= item.length; i++) {
                            switch (funcion) {
                                case 1:
                                    document.getElementById('esta_pers').options[count] = new Option(item[i].desc_esta, item[i].esta_pers);
                                    count++;
                                    break;
                            
                                case 2:
                                        document.getElementById('esta_pers').options[count] = new Option(item[i].desc_esta, item[i].esta_pers);
                                    if (item[i].esta_pers == estado) {
                                        i++;
                                        document.getElementById('esta_pers').selectedIndex=i;
                                        i--;
                                    }
                                    count++;
                                    break;
                            }
                        }
                    }

                } catch (error) {

                }


            }
        );
    }

    getTipoEstudio(estudio, funcion) {
        let count = 1;
        $.post(
            URL + "persona/getTipoEstudio", {},
            (response) => {
                //console.log(response);
                try {
                    let item = JSON.parse(response);
                    document.getElementById('nivel_educativo').options[0] = new Option("Seleccione un nivel educativo", 0);
                    if (item.length > 0) {
                        for (let i = 0; i <= item.length; i++) {
                            switch (funcion) {
                                case 1:
                                    document.getElementById('nivel_educativo').options[count] = new Option(item[i].descripcion, item[i].id);
                                    count++;
                                    break;
                            
                                case 2:
                                        document.getElementById('nivel_educativo').options[count] = new Option(item[i].descripcion, item[i].id);
                                    if (item[i].nivel_educativo == estudio) {
                                        i++;
                                        document.getElementById('nivel_educativo').selectedIndex=i;
                                        i--;
                                    }
                                    count++;
                                    break;
                            }
                        }
                    }

                } catch (error) {

                }


            }
        );
    }

    getListaEstudios(valor,page){
        $.post(
            URL+"persona/getListaEstudios",
            {
                filter:valor,
                page:page
            },
            (response)=>{
                console.log(response);
                //$("#resultsUser").html(response);
                try{
                    let item=JSON.parse(response);
                    console.log(response);
                    $("#resultsEstudios").html(item.dataResults);
                    $("#paginador").html(item.paginador);

                }catch(error){
                    $("#paginador").html(response);
                }
            }
        );
    }

    registerDatosPersonales(){

    }

    //Obtener información del usuario
    dataPersona(data){
        this.funcion=1;
        this.id_persona=data.id;
        this.perfil=data.foto_pers;
        document.getElementById("fotos").innerHTML=['<img class="foto-perfil" src="',PATHNAME+"/resource/images/perfiles/personas/"+data.foto_pers, '" title="', escape(data.foto_pers), '"/>'].join('');
        document.getElementById("nomb_pers").value =data.nomb_pers;
        document.getElementById("ape_pers").value =data.ape_pers;
        document.getElementById("id").value =data.id;
        document.getElementById("direccion").value =data.direccion;
        this.getIdentificaciones(data.codi_iden,2);
        this.getEstadoCivil(data.esta_pers,2)
    }

}