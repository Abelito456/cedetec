class Empresa{
    constructor() {
        //objetos para actualizar datos
        this.funcion=0;
        //id del usuario que se va actualizar
        this.id_empresa=0;
    }
    
    //Llenar select de categorías laborales
    getCategorias_laborales(cat, funcion) {
        let count = 1;
        $.post(
            URL + "empresa/getCategorias_laborales", {},
            (response) => {
                try {
                    let item = JSON.parse(response);
                    //console.log(item);
                    document.getElementById('categoria').options[0] = new Option("Seleccione una categoría", 0);
                    if (item.results.length > 0) {
                        for (let i = 0; i <= item.results.length; i++) {
                            switch (funcion) {
                                case 1:
                                    document.getElementById('categoria').options[count] = new Option(item.results[i].descripcion, item.results[i].id);
                                    count++;
                                break;
                            
                                case 2:
                                    document.getElementById('categoria').options[count] = new Option(item.results[i].descripcion, item.results[i].id);
                                    if (item.results[i].id == cat) {
                                        i++;
                                        document.getElementById('categoria').selectedIndex=i;
                                        i--;
                                    }
                                    count++;
                                    break;
                            }

                        }
                    }

                } catch (error) {

                }


            }
        );
    }
    
    //Llena select de tipos de contratos laborales
    getContratos(contrato, funcion) {
        let count = 1;
        $.post(
            URL + "empresa/getContratos", {},
            (response) => {
                try {
                    let item = JSON.parse(response);
                    //console.log(item);
                    document.getElementById('t_contrato').options[0] = new Option("Seleccione un tipo de contrato", 0);
                    if (item.results.length > 0) {
                        for (let i = 0; i <= item.results.length; i++) {
                            switch (funcion) {
                                case 1:
                                    document.getElementById('t_contrato').options[count] = new Option(item.results[i].descripcion, item.results[i].id);
                                    count++;
                                break;
                            
                                case 2:
                                    document.getElementById('t_contrato').options[count] = new Option(item.results[i].descripcion, item.results[i].id);
                                    if (item.results[i].id == contrato) {
                                        i++;
                                        document.getElementById('t_contrato').selectedIndex=i;
                                        i--;
                                    }
                                    count++;
                                    break;
                            }

                        }
                    }

                } catch (error) {

                }


            }
        );
    }
    
    getConvocatorias(valor,page){
        var valor = valor != null ? valor : "";
        $("#resultsConvo").html('<div class="d-flex justify-content-center"><div class="spinner-border text-info" role="status"><span class="sr-only">Loading...</span></div></div>');

        $.post(
            URL+"empresa/getConvocatorias",
            {
                filter:valor,
                page:page
            },
            (response)=>{
                
                //console.log(response);
                //$("#resultsUser").html(response);
                try{
                    let item=JSON.parse(response);
                    $("#resultsConvo").html(item.dataFilter);
                    $("#paginador").html(item.paginador);
                    
                    
                      
                }catch(error){
                    $("#paginador").html(response);
                }
            }
        );
    }
    
    //registro de convocatorias
    registerConvocatorias(){
        var valor=false;
        var data =new FormData();
        
        var url=this.funcion == 0 ? "empresa/registerConvocatorias" : "empresa/editConvocatoria";
        
        let t_contrato = document.getElementById("t_contrato");
        let contrato = t_contrato.options[t_contrato.selectedIndex].value;
        let categoria = document.getElementById("categoria");
        let categoria_lab = categoria.options[categoria.selectedIndex].value;
                
        data.append('nomb_cargo', $("#nomb_cargo").val());
        data.append('perfil', $("#perfil").val());
        data.append('desc_cargo', $("#desc_cargo").val());
        data.append('categoria_lab', categoria_lab);
        data.append('contrato', contrato);
        data.append('salario', $("#salario").val());
        if( $("#vi_salario").is(':checked') ) {
            data.append('vi_salario', "1");
        }else{
            data.append('vi_salario', "0");
        }
        data.append('id_empresa', this.id_empresa);
        data.append('estado', $("#estado").val());
        data.append('fecha_ini', $("#fecha_ini").val());
        data.append('fecha_fin', $("#fecha_fin").val());
        
        $.ajax({
           url:URL+url,
           data:data,
           cahe:false,
           contentType:false,
           processData:false,
           type:'POST',
           success:(response)=>{
               console.log(response);
               if(response == 0){
                   this.restablecerConvocatoria();
                   valor=false;
               }else{
                   toastr.error(response, '¡Error!', {
                                "progressBar": true,
                                "positionClass": "toast-bottom-right"
                            });
                   valor=true;
               }
           }
        });
        
        return valor;
    }
    
    //restablecer user (PANEL ADMIN)
    restablecerConvocatoria() {
        document.getElementById("registerConvocatoria").innerHTML="REGISTRAR";
        document.getElementById("addconvoTitle").innerHTML="Registrar convocatoria laboral";
        
        this.funcion=0;
        this.id_empresa=0;
        
        this.getCategorias_laborales(null,1);
        this.getContratos(null,1);
        
        window.location.href = URL + "empresa/convocatorias";
    }

    buscarPerfil(categoria,funcion){
        let count = 1;
        $.post(
            URL + "empresa/getCategorias", {},
            (response) => {
                try {
                    let item = JSON.parse(response);

                    document.getElementById('id_categoria').options[0] = new Option("Seleccione una categoría.", 0);
                    if (item.results.length > 0) {
                        for (let i = 0; i <= item.results.length; i++) {
                            switch (funcion) {
                                case 1:
                                    document.getElementById('id_categoria').options[count] = new Option(item.results[i].desc_perfil, item.results[i].id);
                                    count++;
                                break;
                            
                                case 2:
                                    document.getElementById('id_categoria').options[count] = new Option(item.results[i].desc_perfil, item.results[i].id);
                                    if (item.results[i].id == categoria) {
                                        i++;
                                        document.getElementById('id_categoria').selectedIndex=i;
                                        i--;
                                    }
                                    count++;
                                    break;
                            }

                        }
                    }

                } catch (error) {

                }


            }
        );
  }

}
